package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Student;
import com.lti.service.StudentService;

@RestController
@RequestMapping(path="students")
@CrossOrigin
public class StudentRestController {
	@Autowired
	private StudentService service;
	//http://localhost:9090/students
	@RequestMapping(method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Student> viewAllStudents(){
		List<Student> students = service.viewAllStudents();
		return students;
	}
	
	
	//http://localhost:9090/students/1
	@RequestMapping(path="{rollno}", method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Student findStudentByRollNumber(@PathVariable("rollno")int rollNumber){
		Student student = service.findStudentByRollNumber(rollNumber);
		return student;
	}
	
	
	//http://localhost:9090/students
		@RequestMapping(method=RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<String> addStudent(@RequestBody Student student){
		   ResponseEntity<String> response;
		   
		  boolean result= service.addStudent(student);
		  if(result){
			  response=new ResponseEntity<String>("student is added",HttpStatus.CREATED);
		  }
		  else{
			  response= new ResponseEntity<String>("student is not added",HttpStatus.INTERNAL_SERVER_ERROR);
		  }
		 
     return response;
		}
		
		@ExceptionHandler(Exception.class)
		public ResponseEntity<String> handleException(Exception ex){
			ResponseEntity<String> error = new ResponseEntity<String>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
			return error;
			
		}
		
		
		@RequestMapping(path= "/delete/{rollno}", method = RequestMethod.GET, produces=MediaType.ALL_VALUE)
		public String deleteStudent(@PathVariable("rollno") int rollNumber){
			int result = service.removeStudent(rollNumber);
			
			return result+" row(s) deleted";
		}
		
		
		
}

