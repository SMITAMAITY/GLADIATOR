package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Occupation;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;
import com.lti.service.WomaniaService;

@RestController
@RequestMapping(path = "step")
@CrossOrigin
public class StepRestController {
	@Autowired
	private WomaniaService service;

	// http://localhost:9090/step
	@RequestMapping(method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<StepRegister> viewAllSteps() {
		List<StepRegister> step = service.findAllStepDetails();
		return step;
	}

	// http://localhost:9090/step/stepPersonal
	@RequestMapping(path = "/stepPersonal", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<StepPersonalDetails> viewAllStepPersonalDetails() {
		List<StepPersonalDetails> step = service.findAllPersonalDetails();
		return step;
	}

	// http://localhost:9090/step/stepOccupation
	@RequestMapping(path = "/stepOccupation", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Occupation> viewAllStepOccupationDetails() {
		List<Occupation> step = service.findAllStepOccupationDetails();
		return step;
	}

	// http://localhost:9090/step/stepPersonalOccupation
		@RequestMapping(path = "/stepPersonalOccupation", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public List<StepPersonalDetails> viewAllStepPersonalOccupation() {
			List<StepPersonalDetails> step = service.findStepPersonalWithOccupation();
			return step;
		}
}
