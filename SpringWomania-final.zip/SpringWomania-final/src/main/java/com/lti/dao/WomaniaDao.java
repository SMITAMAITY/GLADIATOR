package com.lti.dao;

import java.util.List;

import com.lti.model.Occupation;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;

public interface WomaniaDao {
	//select data from table
	public List<StepRegister> readAllStepDetails();
	public List<StepPersonalDetails> readStepPersonalDetails();
	public List<Occupation> readStepOccupationDetails();
	public List<StepPersonalDetails> readStepPersonalWithOccupation();
}
