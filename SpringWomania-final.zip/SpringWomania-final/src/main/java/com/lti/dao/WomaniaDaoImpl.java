package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lti.model.Occupation;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;

@Repository
public class WomaniaDaoImpl implements WomaniaDao {
	@PersistenceContext
	private EntityManager entityManager;

	public WomaniaDaoImpl()
	{
		
	}

	@Override
	public List<StepRegister> readAllStepDetails() {
		String jpql = "From StepRegister";
		TypedQuery<StepRegister> tquery = entityManager.createQuery(jpql, StepRegister.class);
		return tquery.getResultList();
	
	}

	@Override
	public List<StepPersonalDetails> readStepPersonalDetails() {
		String jpql = "From StepPersonalDetails";
		TypedQuery<StepPersonalDetails> tquery = entityManager.createQuery(jpql, StepPersonalDetails.class);
		List<StepPersonalDetails> result = tquery.getResultList();
		System.out.println(result);
		return result;
	}

	@Override
	public List<Occupation> readStepOccupationDetails() {
		String jpql = "From Occupation";
		TypedQuery<Occupation> tquery = entityManager.createQuery(jpql, Occupation.class);
		return tquery.getResultList();
	}

	@Override
	public List<StepPersonalDetails> readStepPersonalWithOccupation() {
		String jpql = "From StepPersonalDetails"; //where occupation in(select occupationId from Occupation where occupationName='Self-Employed'";
		TypedQuery<StepPersonalDetails> tquery = entityManager.createQuery(jpql, StepPersonalDetails.class);
		System.out.println("123");
		return tquery.getResultList();
	}

}
