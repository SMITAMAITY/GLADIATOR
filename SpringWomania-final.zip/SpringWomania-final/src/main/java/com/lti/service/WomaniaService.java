package com.lti.service;

import java.util.List;

import com.lti.model.Occupation;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;

public interface WomaniaService {
	//select statements
	public  List<StepRegister> findAllStepDetails();
	public List<StepPersonalDetails> findAllPersonalDetails();
	public List<Occupation> findAllStepOccupationDetails();
	public List<StepPersonalDetails> findStepPersonalWithOccupation();
 }
