package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.WomaniaDao;
import com.lti.model.Occupation;
import com.lti.model.StepPersonalDetails;
import com.lti.model.StepRegister;

@Service("service")
public class WomaniaServiceImpl implements WomaniaService {
	@Autowired
	private WomaniaDao dao;

	@Override
	public List<StepRegister> findAllStepDetails() {
		return dao.readAllStepDetails();
		
	}

	@Override
	public List<StepPersonalDetails> findAllPersonalDetails() {
		return dao.readStepPersonalDetails();
	}

	@Override
	public List<Occupation> findAllStepOccupationDetails() {
		return dao.readStepOccupationDetails();
	}

	@Override
	public List<StepPersonalDetails> findStepPersonalWithOccupation() {
		return dao.readStepPersonalWithOccupation();
	}

	

}
