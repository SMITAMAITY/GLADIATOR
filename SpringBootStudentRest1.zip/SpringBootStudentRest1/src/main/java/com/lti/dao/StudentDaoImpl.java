package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lti.model.Student;
import com.lti.utils.JpaUtils;
@Repository
public class StudentDaoImpl implements StudentDao {
	private EntityManager entityManager;
	public StudentDaoImpl()
	{
		entityManager = JpaUtils.getEntityManager();
	}
	@Override
	public int createStudent(Student student) {
		entityManager.getTransaction().begin();
		entityManager.persist(student);
		entityManager.getTransaction().commit();
		return 1;
		
	}

	@Override
	public Student readStudentByRollNumber(int rollNumber) {
		
		return entityManager.find(Student.class, rollNumber);
	}

	@Override
	public List<Student> readAllStudents() {
		String jpql = "From Student";
		TypedQuery<Student> tquery = entityManager.createQuery(jpql,Student.class);
		return tquery.getResultList();
	}
	@Override
	public int deleteStudent(int rollNumber) {
		String jpql = "DELETE FROM Student WHERE rollNumber = :rollno";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("rollno", rollNumber);
		entityManager.getTransaction().begin();
		int result = query.executeUpdate();
		entityManager.getTransaction().commit();
		return result;
		
	
	}
	@Override
	public int modifyStudent(int rollNumber) {
	String jpql = "Update Student Set studentName=name where roll_Number=rollNumber";
		return 0;
	}
	
	

}
