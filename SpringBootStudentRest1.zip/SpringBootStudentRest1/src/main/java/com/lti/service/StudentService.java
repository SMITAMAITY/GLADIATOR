package com.lti.service;

import java.util.List;

import com.lti.model.Student;

public interface StudentService {
	public boolean addStudent(Student student);
	public Student findStudentByRollNumber(int rollNumber);
	public int removeStudent(int rollNumber);
	public boolean modifyStudentByRollNumber(String name,int rollNumber);
	public List<Student> viewAllStudents();
	
}
